import { DatePipe } from '@angular/common';
import { Component, effect, ElementRef, input, model, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CustomDatePickerComponent } from '../../shared/component/custom-date-picker/custom-date-picker.component';
import { SelectComponent } from '../../shared/component/drop-down/drop-down.component';
import { IHeaderCell } from '../../types/interfaces';

@Component({
  selector: 'grid-cell',
  standalone: true,
  imports: [FormsModule, DatePipe, CustomDatePickerComponent, SelectComponent],
  templateUrl: './cell.component.html',
  styleUrl: './cell.component.css'
})
export class CellComponent {

  @ViewChild('inputElement') inputElement?: ElementRef;
  cell = model<any>();
  currentCell = input<IHeaderCell>();
  focused = input<boolean>();

  currentValue: any;

  constructor() {
    effect(() => {
      if (this.focused() && this.inputElement) this.inputElement.nativeElement.focus();
    })
  }

  ngOnInit() {
    this.currentValue = this.cell();
  }  

  saveValue(changedValue: any) {
    this.cell.set(changedValue);
  }

  onSearch(query: string) {
    console.log('Search Query:', query);
  }
}
