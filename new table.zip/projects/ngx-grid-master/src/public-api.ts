/*
 * Public API Surface of ngx-grid-master
 */

export * from "./lib/components/grid-master/grid-master.component"
export * from "./lib/types/interfaces"
